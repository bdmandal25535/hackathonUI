package in.hcl.com.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Borrowing_Power_Calculator_Page  {

	@FindBy(xpath="//div[contains(text(),'Just me')]")
	private WebElement justmeOption;
	
	@FindBy(xpath="//span[@class='nav-text style-scope pl-carousel']")
	private WebElement nextBtn;
	public void selectJustme(){
		justmeOption.click();
		nextBtn.click();
	}
}
