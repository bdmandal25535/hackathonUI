package in.hcl.com.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith((Cucumber.class))
@CucumberOptions(features = "./src/main/java/feature/Borrowing_Power_Calculator.feature",
glue={"stepDefinition"},
plugin={"pretty", "html:target/Destination"})
 

public class Runner_Test {

}

