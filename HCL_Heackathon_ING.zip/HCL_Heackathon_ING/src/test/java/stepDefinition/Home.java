package stepDefinition;

import org.junit.Before;
import org.junit.Test;

import in.hcl.com.base.TestBase;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Home extends TestBase {

	@Given("launch the browser enter the url")
	public void launch_the_browser_enter_the_url() {
		initialization();  
	}

	@When("get the url page title")
	public void get_the_url_page_title() {
	 System.out.println("hfgh");   
	}

	@Then("verify the title of page")
	public void verify_the_title_of_page() {
		System.out.println("hfgh");  
	}

}
