package stepDefinition;

import in.hcl.com.base.TestBase;
import in.hcl.com.page.Borrowing_Power_Calculator_Page;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Borrowing_Power_Calculator_Test extends TestBase {

	Borrowing_Power_Calculator_Page borrowing;
	@Given("i want to launch the Borrowing power calculator")
	public void i_want_to_launch_the_Borrowing_power_calculator() {
		initialization();
	}

	@Given("select the JUST ME option")
	public void select_the_JUST_ME_option() {
		//borrowing.selectJustme();
	}

	@When("enter the all value in the text field")
	public void enter_the_all_value_in_the_text_field() {
		System.out.println("hello");  
	}

	@Then("when we click on next button new page should be open")
	public void when_we_click_on_next_button_new_page_should_be_open() {
		System.out.println("hello");
	}

}
